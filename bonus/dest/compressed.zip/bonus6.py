contents = ["content1","content2","content3"]

filenames = ["doc.txt","report.txt","presentation.txt"]

for content, filename in zip(contents,filenames):
    file = open(f"files/{filename}","w")
    file.writelines(content)